
# command line application

Appication allows the user to enter and store ingredients and steps for one recipe

You enter the number of ingredients:
You enter the the name of each ingredient:
You enter the quantity of an ingredients you picked:
Enter the unit of measurement(mg,g,ml,l):
Than you enter the number of steps of making a recipe:
You can scale the recipe:
You can chose to clear or keep the recipe:
