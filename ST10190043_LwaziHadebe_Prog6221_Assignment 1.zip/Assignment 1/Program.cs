﻿using System;
using System.Collections.Generic;

namespace Assignment_1
{
    class Recipe
    {
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void AddIngredient(string name, double quantity, string unit)
        {
            Ingredients.Add(new Ingredient(name, quantity, unit));
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
        }

        public void ClearRecipe()
        {
            Ingredients.Clear();
            Steps.Clear();
        }
    }
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public double OriginalQuantity { get; set; }
        public string Unit { get; set; }

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            OriginalQuantity = quantity;
            Unit = unit;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter the name of ingredient {i + 1}: ");
                string name = Console.ReadLine();

                Console.Write($"Enter the quantity of {name} (in grams, milliliters, etc.): ");
                double quantity = double.Parse(Console.ReadLine());

                Console.Write($"Enter the unit of measurement for {quantity} {name}: ");
                string unit = Console.ReadLine();

                recipe.AddIngredient(name, quantity, unit);
            }

            Console.Write("\nEnter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                string step = Console.ReadLine();

                recipe.AddStep(step);
            }

            Console.WriteLine("\nHere is your recipe:");
            recipe.DisplayRecipe();

            while (true)
            {
                Console.Write("\nWould you like to scale the recipe? (y/n): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "y")
                {
                    Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());

                    recipe.ScaleRecipe(factor);
                    recipe.DisplayRecipe();
                }
                else
                {
                    break;
                }
            }

            while (true)
            {
                Console.Write("\nWould you like to reset the quantities to their original values? (y/n): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "y")
                {
                    recipe.ResetQuantities();
                    recipe.DisplayRecipe();
                }
                else
                {
                    break;
                }
            }

            while (true)
            {
                Console.Write("\nWould you like to clear the recipe and start over? (y/n): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "y")
                {
                    recipe.ClearRecipe();

                    Console.Write("\nEnter the number of ingredients: ");
                    numIngredients = int.Parse(Console.ReadLine());

                    for (int i = 0; i < numIngredients; i++)
                    {
                        Console.Write($"Enter the name of ingredient {i + 1}: ");
                        string name = Console.ReadLine();

                        Console.Write($"Enter the quantity of {name} (in grams, milliliters, etc.): ");
                        double quantity = double.Parse(Console.ReadLine());

                        Console.Write($"Enter the unit of measurement for {quantity} {name}: ");
                        string unit = Console.ReadLine();

                        recipe.AddIngredient(name, quantity, unit);
                    }

                    Console.Write("\nEnter the number of steps: ");
                    numSteps = int.Parse(Console.ReadLine());

                    for (int i = 0; i < numSteps; i++)
                    {
                        Console.Write($"Enter step {i + 1}: ");
                        string step = Console.ReadLine();

                        recipe.AddStep(step);
                    }
                }
            }
        }
    }
}